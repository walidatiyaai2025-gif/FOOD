<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\B2bCustomer;
use App\Models\B2cCustomer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatusHistory;
use App\Models\Payment;
use App\Models\User;
use App\Services\AuditLogger;
use App\Services\CustomerDomainResolver;
use App\Services\DashboardOperationalNotifier;
use App\Services\OperationalTenantScope;
use App\Services\OrderInventoryReservationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    private const TRANSITIONS = [
        'pending' => ['confirmed', 'cancelled'],
        'confirmed' => ['preparing', 'cancelled'],
        'preparing' => ['ready', 'cancelled'],
        'ready' => ['out_for_delivery', 'cancelled'],
        'out_for_delivery' => ['delivered', 'failed'],
        'failed' => ['out_for_delivery', 'cancelled'],
        'delivered' => [],
        'cancelled' => [],
    ];

    public function index(Request $request): JsonResponse
    {
        [$customer, $channel] = $this->customerContext($request);

        $validated = $request->validate([
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'min:1', 'max:100'],
        ]);

        $customerColumn = $channel === 'b2b' ? 'b2b_customer_id' : 'b2c_customer_id';

        $paginator = Order::query()
            ->where($customerColumn, $customer->getKey())
            ->where('channel', $channel)
            ->latest('id')
            ->paginate((int) ($validated['per_page'] ?? 20));

        return response()->json([
            'data' => collect($paginator->items())
                ->map(fn (Order $order): array => $this->orderPayload($order))
                ->values()
                ->all(),
            'meta' => [
                'current_page' => $paginator->currentPage(),
                'per_page' => $paginator->perPage(),
                'total' => $paginator->total(),
            ],
        ]);
    }

    public function show(Request $request, int $order): JsonResponse
    {
        [$customer, $channel] = $this->customerContext($request);

        $customerColumn = $channel === 'b2b' ? 'b2b_customer_id' : 'b2c_customer_id';

        $model = Order::query()
            ->whereKey($order)
            ->where($customerColumn, $customer->getKey())
            ->where('channel', $channel)
            ->firstOrFail();

        return response()->json($this->orderPayload($model));
    }

    public function transition(
        Request $request,
        int $order,
        AuditLogger $auditLogger,
        DashboardOperationalNotifier $dashboardNotifier,
    ): JsonResponse {
        $validated = $request->validate([
            'status' => [
                'required',
                'string',
                Rule::in(array_keys(self::TRANSITIONS)),
            ],
            'note' => ['nullable', 'string', 'max:1000'],
        ]);

        $user = $request->user();
        abort_unless($user instanceof User, 401);

        $model = Order::query()->findOrFail($order);
        abort_unless($this->canManageOrder($user, $model), 403);

        $previousStatus = (string) $model->status;
        $targetStatus = (string) $validated['status'];
        $note = isset($validated['note']) ? (string) $validated['note'] : null;

        /** @var Order $updated */
        $updated = DB::transaction(function () use (
            $model,
            $user,
            $targetStatus,
            $note,
            $auditLogger,
            $request,
        ): Order {
            $locked = Order::query()->whereKey($model->getKey())->lockForUpdate()->firstOrFail();
            $currentStatus = (string) $locked->status;

            if ($currentStatus === $targetStatus) {
                return $locked;
            }

            $allowed = self::TRANSITIONS[$currentStatus] ?? [];
            abort_unless(
                in_array($targetStatus, $allowed, true),
                409,
                "Order cannot transition from {$currentStatus} to {$targetStatus}.",
            );

            if ($targetStatus === 'cancelled') {
                app(OrderInventoryReservationService::class)->release($locked, $user);
            } elseif ($targetStatus === 'delivered') {
                app(OrderInventoryReservationService::class)->consume($locked, $user);
            }

            $locked->status = $targetStatus;
            $locked->save();

            OrderStatusHistory::query()->create([
                'order_id' => $locked->getKey(),
                'store_id' => (int) $locked->store_id,
                'user_id' => $user->getKey(),
                'from_status' => $currentStatus,
                'to_status' => $targetStatus,
                'note' => $note,
            ]);

            $auditLogger->record(
                'order.status_changed',
                $user,
                $locked,
                ['status' => $currentStatus],
                ['status' => $targetStatus, 'note' => $note],
                $request,
            );

            return $locked;
        }, 3);

        $fresh = $updated->fresh();
        $dashboardNotifier->orderStatusChanged($fresh, $previousStatus, (string) $fresh->status);

        return response()->json($this->orderPayload($fresh));
    }

    /** @return array{0: B2bCustomer|B2cCustomer, 1: string} */
    private function customerContext(Request $request): array
    {
        $user = $request->user();
        abort_unless($user instanceof User, 401);

        $resolver = app(CustomerDomainResolver::class);

        if ($request->is('api/v1/b2b/*')) {
            return [$resolver->b2b($user), 'b2b'];
        }

        return [$resolver->b2cFromRequest($user, $request), 'b2c'];
    }

    private function canManageOrder(User $user, Order $order): bool
    {
        return in_array(
            (int) $order->store_id,
            app(OperationalTenantScope::class)->allowedStoreIds(
                $user,
                'orders.manage',
                (string) $order->channel,
            ),
            true,
        );
    }

    private function orderPayload(Order $order): array
    {
        $items = OrderItem::query()
            ->where('order_id', $order->getKey())
            ->orderBy('id')
            ->get()
            ->map(static fn (OrderItem $item): array => [
                'id' => (int) $item->getKey(),
                'product_id' => (int) $item->product_id,
                'sku' => (string) $item->sku_snapshot,
                'name' => (string) $item->name_snapshot,
                'quantity' => (float) $item->quantity,
                'unit_price' => (float) $item->unit_price,
                'line_total' => (float) $item->line_total,
            ])
            ->values()
            ->all();

        $history = OrderStatusHistory::query()
            ->where('order_id', $order->getKey())
            ->where('store_id', (int) $order->store_id)
            ->orderBy('id')
            ->get()
            ->map(static fn (OrderStatusHistory $entry): array => [
                'id' => (int) $entry->getKey(),
                'from_status' => $entry->from_status,
                'to_status' => (string) $entry->to_status,
                'note' => $entry->note,
                'created_at' => $entry->created_at?->toAtomString(),
            ])
            ->values()
            ->all();

        $payment = Payment::query()
            ->where('order_id', $order->getKey())
            ->latest('id')
            ->first();

        return [
            'id' => (int) $order->getKey(),
            'order_number' => (string) $order->order_number,
            'store_id' => (int) $order->store_id,
            'address_id' => $order->address_id === null ? null : (int) $order->address_id,
            'channel' => (string) $order->channel,
            'status' => (string) $order->status,
            'currency' => (string) $order->currency,
            'subtotal' => (float) $order->subtotal,
            'discount_total' => (float) $order->discount_total,
            'delivery_total' => (float) $order->delivery_total,
            'grand_total' => (float) $order->grand_total,
            'payment_method' => $order->payment_method,
            'items' => $items,
            'status_history' => $history,
            'payment' => $payment instanceof Payment ? [
                'id' => (int) $payment->getKey(),
                'provider' => (string) $payment->provider,
                'status' => (string) $payment->status,
                'amount' => (float) $payment->amount,
                'currency' => (string) $payment->currency,
            ] : null,
            'created_at' => $order->created_at?->toAtomString(),
        ];
    }
}
