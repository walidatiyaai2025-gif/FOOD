<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\FleetCurrentLocation;
use App\Models\Order;
use App\Models\User;
use App\Models\Van;
use App\Models\VanAssignment;
use App\Services\FleetLocationService;
use App\Services\OperationalTenantScope;
use App\Services\OrderLiveTrackingService;
use Carbon\CarbonImmutable;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\Rule;

class FleetLocationController extends Controller
{
    public function vanHeartbeat(Request $request, FleetLocationService $service): JsonResponse
    {
        Gate::authorize('drivers.b2b.manage');

        $data = $request->validate([
            'van_id' => ['required', 'integer', 'min:1'],
            'assignment_id' => ['nullable', 'integer', 'min:1'],
            'route_key' => ['nullable', 'string', 'max:128'],
            'store_id' => ['nullable', 'integer', 'min:1'],
            'channel' => ['nullable', Rule::in(['b2b', 'b2c'])],
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'accuracy' => ['nullable', 'numeric', 'min:0', 'max:100000'],
            'speed' => ['nullable', 'numeric', 'min:0', 'max:500'],
            'heading' => ['nullable', 'numeric', 'between:0,360'],
            'captured_at' => ['required', 'date', 'before_or_equal:'.now()->addMinutes(5)->toDateTimeString()],
            'app_version' => ['nullable', 'string', 'max:64'],
            'is_mocked' => ['nullable', 'boolean'],
        ]);

        $location = $service->heartbeat('van', (int) $data['van_id'], [
            'vehicle_id' => (int) $data['van_id'],
            'assignment_id' => $data['assignment_id'] ?? null,
            'route_key' => $data['route_key'] ?? null,
            'store_id' => $data['store_id'] ?? null,
            'channel' => $data['channel'] ?? null,
            'latitude' => $data['latitude'],
            'longitude' => $data['longitude'],
            'accuracy' => $data['accuracy'] ?? null,
            'speed' => $data['speed'] ?? null,
            'heading' => $data['heading'] ?? null,
            'captured_at' => $data['captured_at'],
            'source_app' => 'van',
            'app_version' => $data['app_version'] ?? null,
            'is_mocked' => $data['is_mocked'] ?? null,
        ]);

        return response()->json(['data' => $this->serialize($location, $service)]);
    }

    public function vanRuntimeHeartbeat(Request $request, FleetLocationService $service): JsonResponse
    {
        $context = $request->attributes->get('van_runtime_context');
        abort_unless(is_array($context), 403, 'Van runtime context is unavailable.');

        $vanId = (int) ($context['van_id'] ?? 0);
        $assignmentId = (int) ($context['assignment_id'] ?? 0);
        abort_unless($vanId > 0 && $assignmentId > 0, 403, 'No effective Van assignment is available.');

        $data = $request->validate([
            'route_key' => ['nullable', 'string', 'max:128'],
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'accuracy' => ['nullable', 'numeric', 'min:0', 'max:100000'],
            'speed' => ['nullable', 'numeric', 'min:0', 'max:500'],
            'heading' => ['nullable', 'numeric', 'between:0,360'],
            'captured_at' => ['required', 'date', 'before_or_equal:'.now()->addMinutes(5)->toDateTimeString()],
            'app_version' => ['nullable', 'string', 'max:64'],
            'is_mocked' => ['nullable', 'boolean'],
        ]);

        $warehouseId = isset($context['warehouse_id']) ? (int) $context['warehouse_id'] : 0;
        if ($warehouseId <= 0) {
            $warehouseId = (int) (Van::query()->whereKey($vanId)->value('home_warehouse_id') ?? 0);
        }

        $storeId = $warehouseId > 0
            ? DB::table('warehouses')->where('id', $warehouseId)->value('store_id')
            : null;

        $driverId = isset($context['driver_id']) ? (int) $context['driver_id'] : 0;
        if ($storeId === null && $driverId > 0) {
            $storeId = DB::table('drivers')->where('id', $driverId)->value('store_id');
        }

        $location = $service->heartbeat('van', $vanId, [
            'vehicle_id' => $vanId,
            'assignment_id' => $assignmentId,
            'route_key' => $data['route_key'] ?? null,
            'store_id' => $storeId === null ? null : (int) $storeId,
            'channel' => 'b2b',
            'latitude' => $data['latitude'],
            'longitude' => $data['longitude'],
            'accuracy' => $data['accuracy'] ?? null,
            'speed' => $data['speed'] ?? null,
            'heading' => $data['heading'] ?? null,
            'captured_at' => $data['captured_at'],
            'source_app' => 'van',
            'app_version' => $data['app_version'] ?? null,
            'is_mocked' => $data['is_mocked'] ?? null,
        ]);

        return response()->json(['data' => $this->serialize($location, $service)]);
    }

    public function feed(
        Request $request,
        FleetLocationService $service,
        OperationalTenantScope $tenantScope,
        OrderLiveTrackingService $orderTracking,
    ): JsonResponse {

        $user = $request->user();
        abort_unless($user instanceof User, 401);

        $data = $request->validate([
            'actor_type' => ['nullable', Rule::in(['driver', 'van'])],
            'actor_id' => ['nullable', 'integer', 'min:1'],
            'route_key' => ['nullable', 'string', 'max:128'],
            'order_id' => ['nullable', 'integer', 'min:1'],
            'store_id' => ['nullable', 'integer', 'min:1'],
            'channel' => ['nullable', Rule::in(['b2b', 'b2c'])],
            'status' => ['nullable', Rule::in(['online', 'stale', 'offline'])],
            'north' => ['nullable', 'numeric', 'between:-90,90'],
            'south' => ['nullable', 'numeric', 'between:-90,90'],
            'east' => ['nullable', 'numeric', 'between:-180,180'],
            'west' => ['nullable', 'numeric', 'between:-180,180'],
        ]);

        $channels = isset($data['channel']) ? [(string) $data['channel']] : ['b2b', 'b2c'];
        $allowedStoresByChannel = [];

        foreach ($channels as $channel) {
            $storeIds = $tenantScope->allowedStoreIds($user, 'drivers.tracking.view', $channel);
            if ($storeIds !== []) {
                $allowedStoresByChannel[$channel] = $storeIds;
            }
        }

        abort_if($allowedStoresByChannel === [], 403);

        if (isset($data['store_id'])) {
            $requestedStoreId = (int) $data['store_id'];
            foreach ($allowedStoresByChannel as $channel => $storeIds) {
                if (in_array($requestedStoreId, $storeIds, true)) {
                    $allowedStoresByChannel[$channel] = [$requestedStoreId];
                } else {
                    unset($allowedStoresByChannel[$channel]);
                }
            }
            abort_if($allowedStoresByChannel === [], 404);
        }

        $trackedOrder = null;
        $trackedOrderPayload = null;
        $trackedVanId = null;

        if (isset($data['order_id'])) {
            $trackedOrder = Order::query()->find((int) $data['order_id']);
            abort_unless($trackedOrder instanceof Order, 404);

            $orderChannel = strtolower((string) $trackedOrder->channel);
            $orderStoreId = (int) $trackedOrder->store_id;
            abort_unless(
                isset($allowedStoresByChannel[$orderChannel])
                && in_array($orderStoreId, $allowedStoresByChannel[$orderChannel], true),
                404,
            );

            $trackedOrderPayload = $orderTracking->forOrder($trackedOrder);
            if (
                $orderChannel === 'b2b'
                && ($trackedOrderPayload['actor_type'] ?? null) === 'van'
                && ($trackedOrderPayload['van_id'] ?? null) !== null
            ) {
                $trackedVanId = (int) $trackedOrderPayload['van_id'];
            }
        }

        $query = FleetCurrentLocation::query();

        if ($trackedOrder instanceof Order) {
            if ($trackedVanId === null) {
                $query->whereRaw('1 = 0');
            } else {
                $query
                    ->where('actor_type', 'van')
                    ->where('actor_id', $trackedVanId);
            }
        } else {
            $includeUnscopedVans = ($data['actor_type'] ?? null) === 'van' && $user->hasRole('SUPER_ADMIN');

            $query->where(function ($query) use ($allowedStoresByChannel, $includeUnscopedVans): void {
                foreach ($allowedStoresByChannel as $channel => $storeIds) {
                    $query->orWhere(function ($scope) use ($channel, $storeIds): void {
                        $scope->where('channel', $channel)->whereIn('store_id', $storeIds);
                    });
                }

                if ($includeUnscopedVans) {
                    $query->orWhere(function ($scope): void {
                        $scope->where('actor_type', 'van')->whereNull('store_id');
                    });
                }
            });
        }

        $rows = $query
            ->when(isset($data['actor_type']), fn ($query) => $query->where('actor_type', $data['actor_type']))
            ->when(isset($data['actor_id']), fn ($query) => $query->where('actor_id', (int) $data['actor_id']))
            ->when(isset($data['route_key']), fn ($query) => $query->where('route_key', $data['route_key']))
            ->when(isset($data['north']), fn ($query) => $query->where('latitude', '<=', (float) $data['north']))
            ->when(isset($data['south']), fn ($query) => $query->where('latitude', '>=', (float) $data['south']))
            ->when(isset($data['east']), fn ($query) => $query->where('longitude', '<=', (float) $data['east']))
            ->when(isset($data['west']), fn ($query) => $query->where('longitude', '>=', (float) $data['west']))
            ->orderByDesc('received_at')
            ->limit(500)
            ->get()
            ->map(fn (FleetCurrentLocation $location): array => $this->serialize($location, $service))
            ->when(
                isset($data['status']),
                fn ($rows) => $rows->where('status', $data['status'])->values(),
            );

        return response()->json([
            'data' => $rows,
            'meta' => [
                'total' => $rows->count(),
                'generated_at' => CarbonImmutable::now()->toISOString(),
                'freshness' => ['online_seconds' => 45, 'stale_seconds' => 180],
                'order_tracking' => $trackedOrder instanceof Order ? $trackedOrderPayload : null,
            ],
        ]);
    }

    /** @return array<string,mixed> */
    private function serialize(FleetCurrentLocation $location, FleetLocationService $service): array
    {
        $payload = [
            'actor_type' => (string) $location->actor_type,
            'actor_id' => (int) $location->actor_id,
            'vehicle_id' => $location->vehicle_id === null ? null : (int) $location->vehicle_id,
            'assignment_id' => $location->assignment_id === null ? null : (int) $location->assignment_id,
            'route_key' => $location->route_key,
            'store_id' => $location->store_id === null ? null : (int) $location->store_id,
            'channel' => $location->channel,
            'status' => $service->status($location),
            'latitude' => (float) $location->latitude,
            'longitude' => (float) $location->longitude,
            'accuracy' => $location->accuracy === null ? null : (float) $location->accuracy,
            'speed' => $location->speed === null ? null : (float) $location->speed,
            'heading' => $location->heading === null ? null : (float) $location->heading,
            'captured_at' => CarbonImmutable::parse((string) $location->captured_at)->toISOString(),
            'received_at' => CarbonImmutable::parse((string) $location->received_at)->toISOString(),
            'source_app' => $location->source_app,
            'app_version' => $location->app_version,
        ];

        if ((string) $location->actor_type !== 'van') {
            return $payload;
        }

        $van = Van::query()->find((int) $location->actor_id);
        $assignment = $location->assignment_id === null
            ? VanAssignment::query()
                ->where('van_id', (int) $location->actor_id)
                ->where('status', 'active')
                ->orderByDesc('effective_from')
                ->first()
            : VanAssignment::query()->find((int) $location->assignment_id);
        $operator = $assignment?->representative_user_id === null
            ? null
            : User::query()->find((int) $assignment->representative_user_id);

        return [
            ...$payload,
            'entity_name' => $van?->code ?: 'Van #'.(int) $location->actor_id,
            'van' => $van === null ? null : [
                'id' => (int) $van->id,
                'code' => (string) $van->code,
                'plate_number' => $van->plate_number,
                'vehicle_type' => $van->vehicle_type,
                'operational_status' => (string) $van->status,
            ],
            'assignment' => $assignment === null ? null : [
                'id' => (int) $assignment->id,
                'type' => (string) $assignment->assignment_type,
                'territory_key' => $assignment->territory_key,
                'warehouse_id' => $assignment->warehouse_id === null ? null : (int) $assignment->warehouse_id,
                'operator_user_id' => $assignment->representative_user_id === null ? null : (int) $assignment->representative_user_id,
                'operator_name' => $operator?->name,
            ],
        ];
    }
}
