<?php

namespace Database\Seeders;

use App\Services\PlatformCustomerService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use RuntimeException;

class ScreenshotEvidenceSeeder extends Seeder
{
    public function run(): void
    {
        if (app()->environment('production')) {
            throw new RuntimeException('ScreenshotEvidenceSeeder is forbidden in production.');
        }

        $this->call(DashboardDemoSeeder::class);

        $now = now();

        $superAdminId = (int) DB::table('users')->insertGetId([
            'name' => 'FOODEX Screenshot Admin',
            'email' => 'screenshots@foodex.test',
            'email_verified_at' => $now,
            'password' => Hash::make('Evidence123!'),
            'locale' => 'ar',
            'is_active' => true,
            'last_seen_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $superRoleId = (int) DB::table('roles')->where('code', 'SUPER_ADMIN')->value('id');
        DB::table('role_user')->insert(['role_id' => $superRoleId, 'user_id' => $superAdminId]);

        $englishAdminId = (int) DB::table('users')->insertGetId([
            'name' => 'FOODEX Screenshot Admin EN',
            'email' => 'screenshots.en@foodex.test',
            'email_verified_at' => $now,
            'password' => Hash::make('Evidence123!'),
            'locale' => 'en',
            'is_active' => true,
            'last_seen_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('role_user')->insert(['role_id' => $superRoleId, 'user_id' => $englishAdminId]);

        $b2bType = (int) DB::table('store_types')->where('code', 'B2B')->value('id');
        $storeId = (int) DB::table('stores')->insertGetId([
            'store_type_id' => $b2bType,
            'code' => 'FOODEX-EVIDENCE-B2B',
            'name' => 'FOODEX Wholesale Evidence Branch',
            'is_active' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $warehouseId = (int) DB::table('warehouses')->insertGetId([
            'store_id' => $storeId,
            'code' => 'FOODEX-EVIDENCE-B2B-WH',
            'name' => 'FOODEX Wholesale Warehouse',
            'is_active' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $retailStoreId = (int) DB::table('stores')
            ->where('code', 'FOODEX-DEMO-B2C')
            ->value('id');

        $platformUser = app(PlatformCustomerService::class)->register([
            'name' => 'FOODEX Address Evidence Customer',
            'email' => 'evidence.address@foodex.test',
            'phone' => '+96555509999',
            'password' => 'Evidence123!',
            'locale' => 'ar',
            'store_id' => $retailStoreId,
        ], 'dashboard');

        $platformCustomer = DB::table('platform_customers')
            ->where('user_id', $platformUser->id)
            ->first();

        if ($platformCustomer === null) {
            throw new RuntimeException('Platform Customer screenshot fixture was not created.');
        }

        $addressId = (int) DB::table('addresses')->insertGetId([
            'customer_id' => (int) $platformCustomer->legacy_customer_id,
            'platform_customer_id' => (int) $platformCustomer->id,
            'b2b_customer_id' => null,
            'b2c_customer_id' => null,
            'label' => 'Home',
            'recipient_name' => 'FOODEX Address Evidence Customer',
            'delivery_phone' => '+96555509999',
            'line1' => 'Block 1, Street 5, Building 12',
            'line2' => null,
            'city' => 'Kuwait City',
            'area' => 'Bayan',
            'country_code' => 'KW',
            'country' => 'Kuwait',
            'governorate' => 'Hawalli',
            'block' => '1',
            'street' => 'Street 5',
            'avenue' => null,
            'building' => '12',
            'floor' => '2',
            'apartment' => '7',
            'landmark' => 'Near Bayan Co-op',
            'delivery_notes' => 'Call on arrival',
            'latitude' => 29.3031000,
            'longitude' => 48.0489000,
            'location_accuracy_meters' => 6.0,
            'location_source' => 'map_pin',
            'is_default' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $b2cCustomerId = DB::table('b2c_customers')
            ->where('user_id', $platformUser->id)
            ->where('store_id', $retailStoreId)
            ->value('id');

        $deliverySnapshot = [
            'version' => 1,
            'address_id' => $addressId,
            'label' => 'Home',
            'recipient_name' => 'FOODEX Address Evidence Customer',
            'delivery_phone' => '+96555509999',
            'line1' => 'Block 1, Street 5, Building 12',
            'line2' => null,
            'city' => 'Kuwait City',
            'area' => 'Bayan',
            'country_code' => 'KW',
            'country' => 'Kuwait',
            'governorate' => 'Hawalli',
            'block' => '1',
            'street' => 'Street 5',
            'avenue' => null,
            'building' => '12',
            'floor' => '2',
            'apartment' => '7',
            'landmark' => 'Near Bayan Co-op',
            'delivery_notes' => 'Call on arrival',
            'latitude' => 29.3031,
            'longitude' => 48.0489,
            'location_accuracy_meters' => 6.0,
            'location_source' => 'map_pin',
        ];

        DB::table('orders')->insert([
            'store_id' => $retailStoreId,
            'customer_id' => (int) $platformCustomer->legacy_customer_id,
            'b2c_customer_id' => $b2cCustomerId === null ? null : (int) $b2cCustomerId,
            'address_id' => $addressId,
            'delivery_address_snapshot' => json_encode($deliverySnapshot, JSON_THROW_ON_ERROR),
            'delivery_latitude' => 29.3031000,
            'delivery_longitude' => 48.0489000,
            'order_number' => 'FOODEX-EVID-LOC-1',
            'channel' => 'b2c',
            'status' => 'confirmed',
            'currency' => 'KWD',
            'subtotal' => 12.500,
            'discount_total' => 0,
            'delivery_total' => 1.000,
            'grand_total' => 13.500,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $categoryId = (int) DB::table('categories')->insertGetId([
            'name' => 'FOODEX Wholesale',
            'slug' => 'foodex-evidence-wholesale',
            'is_active' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $unitId = (int) DB::table('units')->insertGetId([
            'code' => 'EVID-CS',
            'name' => 'Case',
            'decimal_places' => 0,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $productId = (int) DB::table('products')->insertGetId([
            'category_id' => $categoryId,
            'unit_id' => $unitId,
            'sku' => 'FOODEX-B2B-001',
            'name' => 'FOODEX Wholesale Tomato Case',
            'description' => 'Deterministic screenshot evidence product.',
            'is_active' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('store_products')->insert([
            'store_id' => $storeId,
            'product_id' => $productId,
            'price' => 7.250,
            'is_active' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('inventories')->insert([
            'warehouse_id' => $warehouseId,
            'product_id' => $productId,
            'quantity' => 240,
            'reserved_quantity' => 20,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $tierId = (int) DB::table('b2b_price_tiers')->insertGetId([
            'code' => 'GOLD-EVIDENCE',
            'name' => 'Gold Evidence',
            'priority' => 100,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $customerId = (int) DB::table('customers')->insertGetId([
            'type' => 'b2b',
            'name' => 'FOODEX Business Customer',
            'phone' => '+96555500001',
            'email' => 'buyer@foodex.test',
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('b2b_accounts')->insert([
            'customer_id' => $customerId,
            'price_tier_id' => $tierId,
            'company_name' => 'FOODEX Business Demo',
            'status' => 'active',
            'tax_number' => 'TX-EVID-001',
            'credit_limit' => 5000,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('b2b_price_rules')->insert([
            'price_tier_id' => $tierId,
            'store_id' => $storeId,
            'product_id' => $productId,
            'unit_price' => 6.950,
            'minimum_quantity' => 5,
            'is_active' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $orderId = (int) DB::table('orders')->insertGetId([
            'store_id' => $storeId,
            'customer_id' => $customerId,
            'order_number' => 'FOODEX-B2B-EVID-1001',
            'channel' => 'b2b',
            'status' => 'processing',
            'currency' => 'KWD',
            'subtotal' => 69.500,
            'discount_total' => 0,
            'delivery_total' => 5,
            'grand_total' => 74.500,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('order_items')->insert([
            'order_id' => $orderId,
            'product_id' => $productId,
            'sku_snapshot' => 'FOODEX-B2B-001',
            'name_snapshot' => 'FOODEX Wholesale Tomato Case',
            'quantity' => 10,
            'unit_price' => 6.950,
            'line_total' => 69.500,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        $driverUserId = (int) DB::table('users')->insertGetId([
            'name' => 'سالم · سائق FOODEX أعمال',
            'email' => 'driver.b2b@foodex.test',
            'email_verified_at' => $now,
            'password' => Hash::make('Evidence123!'),
            'locale' => 'ar',
            'is_active' => true,
            'last_seen_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        $driverRoleId = (int) DB::table('roles')->where('code', 'B2B_DRIVER')->value('id');
        DB::table('role_user')->insert(['role_id' => $driverRoleId, 'user_id' => $driverUserId]);
        $driverId = (int) DB::table('drivers')->insertGetId([
            'user_id' => $driverUserId,
            'driver_type' => 'b2b',
            'is_available' => true,
            'is_active' => true,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        DB::table('driver_assignments')->insert([
            'driver_id' => $driverId,
            'order_id' => $orderId,
            'assignment_type' => 'b2b',
            'status' => 'assigned',
            'assigned_at' => $now,
            'created_at' => $now,
            'updated_at' => $now,
        ]);
    }
}
