<!doctype html>
<html lang="{{ app()->getLocale() }}" dir="{{ app()->getLocale()==='ar'?'rtl':'ltr' }}">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ app()->getLocale()==='ar'?'العلامات والوحدات':'Brands & Units' }} · FOODEX</title>
@include('admin._brand-components')
<style>
body{margin:0;background:var(--foodex-background);color:var(--foodex-ink)}
.lookup-layout{direction:ltr;display:grid;grid-template-columns:minmax(0,1fr) var(--foodex-sidebar-width);min-height:100vh}
.lookup-layout aside{grid-column:2;grid-row:1;direction:rtl;background:var(--foodex-surface);border-left:1px solid var(--foodex-border);padding:var(--foodex-space-5)}
.lookup-layout main{grid-column:1;grid-row:1;direction:rtl;padding:var(--foodex-space-6);min-width:0}
html[dir=ltr] .lookup-layout{grid-template-columns:var(--foodex-sidebar-width) minmax(0,1fr)}
html[dir=ltr] .lookup-layout aside{grid-column:1;direction:ltr;border-left:0;border-right:1px solid var(--foodex-border)}
html[dir=ltr] .lookup-layout main{grid-column:2;direction:ltr}
.header{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:18px}.header h1{margin:0 0 6px}.muted{color:var(--foodex-muted)}
.card{background:var(--foodex-surface);border:1px solid var(--foodex-border);border-radius:var(--foodex-radius-card);padding:16px;box-shadow:var(--foodex-shadow-sm);margin-bottom:16px}
.toolbar,.form-grid,.inline-form{display:flex;flex-wrap:wrap;gap:10px;align-items:end}.form-grid label,.inline-form label{display:grid;gap:5px;font-size:12px;font-weight:700}
input,select{border:1px solid var(--foodex-border);border-radius:9px;padding:9px;background:#fff;font:inherit;min-width:130px}.wide{min-width:210px}
.btn{border:1px solid var(--foodex-border);background:#fff;border-radius:9px;padding:9px 12px;text-decoration:none;color:inherit;cursor:pointer;font:inherit}.btn.primary,.tab.active{background:var(--foodex-action-green);color:#fff;border-color:var(--foodex-action-green)}.btn.danger{color:var(--foodex-danger-text)}
.lookup-tab-row{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:16px}.tabs{display:flex;gap:8px;margin:0}.tab{padding:9px 14px;border:1px solid var(--foodex-border);border-radius:10px;text-decoration:none;color:inherit;background:#fff}
.notice{padding:10px 12px;border-radius:10px;margin-bottom:12px}.ok{background:var(--foodex-green-soft);color:var(--foodex-green-dark)}.err{background:#fff1f0;color:var(--foodex-danger-text)}
.table-wrap{overflow:auto}.table{width:100%;border-collapse:collapse;min-width:1040px}.table th,.table td{padding:10px;border-bottom:1px solid var(--foodex-border);text-align:start;vertical-align:top}.table th{background:var(--foodex-background)}
.badge{display:inline-flex;border-radius:999px;padding:4px 8px;font-size:11px;background:#eef2f6}.badge.on{background:var(--foodex-green-soft);color:var(--foodex-green-dark)}.badge.off{background:#f2f4f7;color:#667085}
.actions{display:flex;gap:6px;flex-wrap:wrap}.brand-thumb{width:56px;height:56px;object-fit:contain;border:1px solid var(--foodex-border);border-radius:10px;background:#fff;padding:4px;box-sizing:border-box}.image-help{font-size:11px;color:var(--foodex-muted);max-width:240px}.brand-upload-preview{margin-top:6px}.brand-upload-preview:empty{display:none}.brand-upload-preview img{width:72px;height:72px;object-fit:contain;border:1px solid var(--foodex-border);border-radius:12px;background:#fff;padding:4px;box-sizing:border-box}.support{font-size:11px;color:var(--foodex-muted);display:flex!important;align-items:center;grid-auto-flow:column}.support input{min-width:auto}
.lookup-grid-image{display:grid;gap:7px;justify-items:start}.lookup-grid-image-form{margin:0;display:flex;align-items:center;gap:7px;flex-wrap:wrap}.lookup-grid-image-input{position:absolute!important;width:1px!important;height:1px!important;opacity:0!important;overflow:hidden!important;pointer-events:none}.lookup-grid-image-trigger{display:inline-flex;align-items:center;justify-content:center;padding:6px 9px;border:1px solid var(--foodex-border);border-radius:8px;background:#fff;font-size:11px;font-weight:800;cursor:pointer}.lookup-grid-image-form.is-uploading .lookup-grid-image-trigger{opacity:.6;pointer-events:none}
.lookup-add-btn{display:inline-flex;align-items:center;gap:8px;min-height:44px;padding:10px 16px;font-weight:800;box-shadow:0 8px 20px rgba(16,120,64,.14)}
.lookup-modal[hidden]{display:none}.lookup-modal{position:fixed;inset:0;z-index:120;display:grid;place-items:center;padding:20px}.lookup-modal-backdrop{position:absolute;inset:0;background:rgba(16,24,40,.52);backdrop-filter:blur(3px)}.lookup-modal-dialog{position:relative;z-index:1;width:min(820px,100%);max-height:min(86vh,820px);display:flex;flex-direction:column;background:var(--foodex-surface);border:1px solid var(--foodex-border);border-radius:20px;box-shadow:0 24px 70px rgba(16,24,40,.24);overflow:hidden}.lookup-modal-header{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;padding:20px 22px;border-bottom:1px solid var(--foodex-border);background:linear-gradient(180deg,var(--foodex-green-soft),#fff)}.lookup-modal-header h2{margin:0 0 5px;font-size:22px}.lookup-modal-header p{margin:0;color:var(--foodex-muted);font-size:13px}.lookup-modal-close{width:40px;height:40px;display:grid;place-items:center;border:1px solid var(--foodex-border);border-radius:12px;background:#fff;font-size:24px;line-height:1;cursor:pointer}.lookup-modal-body{padding:22px;overflow:auto}.lookup-modal .form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;align-items:start}.lookup-modal .form-grid label{font-size:13px}.lookup-modal .form-grid input,.lookup-modal .form-grid select{width:100%;min-width:0;box-sizing:border-box}.lookup-modal .support{grid-column:1/-1;justify-content:flex-start}.lookup-modal-actions{display:flex;justify-content:flex-end;gap:10px;padding:16px 22px;border-top:1px solid var(--foodex-border);background:#fbfcfd}.lookup-modal-actions .btn{min-width:110px}.lookup-modal-open{overflow:hidden}
@media(max-width:1023px){.lookup-layout{grid-template-columns:1fr}.lookup-layout aside,.lookup-layout main,html[dir=ltr] .lookup-layout aside,html[dir=ltr] .lookup-layout main{grid-column:1}.lookup-layout aside{grid-row:1}.lookup-layout main{grid-row:2}.header{flex-direction:column}.toolbar{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));align-items:end}.toolbar label,.toolbar input,.toolbar select{min-width:0;width:100%;box-sizing:border-box}}
@media(max-width:720px){.lookup-layout main{padding:var(--foodex-space-4)}.lookup-tab-row{align-items:stretch}.tabs{width:100%;overflow:auto;flex-wrap:nowrap}.tab{white-space:nowrap}.lookup-add-btn{width:100%;justify-content:center}.toolbar{grid-template-columns:1fr}.toolbar .btn{width:100%}.lookup-modal{padding:10px}.lookup-modal-dialog{max-height:92vh;border-radius:16px}.lookup-modal-header,.lookup-modal-body,.lookup-modal-actions{padding:16px}.lookup-modal .form-grid{grid-template-columns:1fr}.lookup-modal .support{grid-column:auto}.table-wrap{overflow:visible;background:transparent;border:0;box-shadow:none;padding:0}.table{display:block;min-width:0;width:100%}.table thead{display:none}.table tbody{display:grid;gap:12px}.table tr.lookup-record-row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:12px;border:1px solid var(--foodex-border);border-radius:14px;background:var(--foodex-surface);box-shadow:var(--foodex-shadow-sm)}.table td{display:grid;gap:5px;padding:7px 8px;border:0;min-width:0}.table td[data-label]::before{content:attr(data-label);font-size:10px;font-weight:800;color:var(--foodex-muted)}.table td.lookup-mobile-full{grid-column:1/-1}.table .inline-form{display:grid;grid-template-columns:1fr;align-items:stretch}.table .inline-form label{min-width:0}.table .inline-form input,.table .inline-form select{width:100%;min-width:0;box-sizing:border-box}.table .actions{display:grid;grid-template-columns:1fr 1fr}.table .actions form,.table .actions .btn{width:100%}.lookup-grid-image{grid-template-columns:auto 1fr;align-items:center}.brand-thumb{width:64px;height:64px}.support{white-space:normal}}
@media(max-width:420px){.table tr.lookup-record-row{grid-template-columns:1fr}.table td.lookup-mobile-full{grid-column:1}.table .actions{grid-template-columns:1fr}.lookup-modal-actions{display:grid;grid-template-columns:1fr}.lookup-modal-actions .btn{width:100%}}
</style>
</head>
<body>
@php
$ar=app()->getLocale()==='ar';
$scopeLabels=['global'=>$ar?'عام للمنصة':'Platform global','b2b'=>$ar?'الجملة B2B':'Wholesale / B2B','store'=>$ar?'متجر تجزئة':'Retail store'];
$createLabel=$type==='brands'?($ar?'إضافة علامة تجارية جديدة':'Add new brand'):($ar?'إضافة وحدة قياس جديدة':'Add new unit');
$createDescription=$type==='brands'?($ar?'أدخل بيانات العلامة وصورتها وحدد نطاق استخدامها.':'Enter brand details, image, and business scope.'):($ar?'أدخل بيانات وحدة القياس وحدد نطاق استخدامها.':'Enter unit details and business scope.');
@endphp
<div class="lookup-layout">
<aside>@include('admin._sidebar',['navContext'=>'lookup_management'])</aside>
<main>
@include('admin._global-header')
<div class="header foodex-page-toolbar"><div><h1>{{ $ar?'العلامات والوحدات':'Brands & Units' }}</h1><div class="muted">{{ $ar?'إدارة العلامات التجارية ووحدات القياس حسب صلاحية ونطاق المستخدم الحالي.':'Manage brands and units inside the current authorized business scope.' }}</div></div></div> {{-- localization-gate: allow — #2078 reclassifies this existing bilingual page copy from legacy header to content toolbar without changing wording. --}}

@if(session('status'))<div class="notice ok">{{ session('status') }}</div>@endif
@if($errors->any())<div class="notice err">@foreach($errors->all() as $error)<div>{{ $error }}</div>@endforeach</div>@endif
@if($isSuperAdmin)<div class="notice">{{ $ar?'تنبيه: تعديل بيانات نطاق متجر تجزئة يتطلب تفعيل «الدعم الصريح» داخل نفس الإجراء. هذا يحافظ على عزل المتاجر ويسجل عملية الدعم.':'Note: Retail store-scoped changes require Explicit support access on the same action. This preserves tenant isolation and audits the support operation.' }}</div>@endif

<div class="lookup-tab-row">
<nav class="tabs">
<a class="tab {{ $type==='brands'?'active':'' }}" href="{{ route('admin.lookups.index',['type'=>'brands']) }}">{{ $ar?'العلامات التجارية':'Brands' }}</a>
<a class="tab {{ $type==='units'?'active':'' }}" href="{{ route('admin.lookups.index',['type'=>'units']) }}">{{ $ar?'وحدات القياس':'Units of Measure' }}</a>
</nav>
@if($manageableScopes!==[])
<button class="btn primary lookup-add-btn" type="button" data-lookup-modal-open>＋ {{ $createLabel }}</button>
@endif
</div>

<section class="card">
<form class="toolbar" method="get" action="{{ route('admin.lookups.index') }}">
<input type="hidden" name="type" value="{{ $type }}">
<label>{{ $ar?'بحث':'Search' }}<input class="wide" name="q" value="{{ $filters['q'] }}" placeholder="{{ $ar?'الاسم أو الكود':'Name or code' }}"></label>
@if($isSuperAdmin)<label>{{ $ar?'النطاق':'Scope' }}<select name="scope"><option value="all">{{ $ar?'كل النطاقات':'All scopes' }}</option>@foreach($scopeLabels as $key=>$label)<option value="{{ $key }}" @selected($filters['scope']===$key)>{{ $label }}</option>@endforeach</select></label>@endif
<label>{{ $ar?'الحالة':'Status' }}<select name="status"><option value="all">{{ $ar?'الكل':'All' }}</option><option value="active" @selected($filters['status']==='active')>{{ $ar?'نشط':'Active' }}</option><option value="inactive" @selected($filters['status']==='inactive')>{{ $ar?'غير نشط':'Inactive' }}</option></select></label>
@if($isSuperAdmin && $stores->isNotEmpty())<label>{{ $ar?'المتجر':'Store' }}<select name="store_id"><option value="">{{ $ar?'كل المتاجر المصرح بها':'All authorized stores' }}</option>@foreach($stores as $store)<option value="{{ $store->id }}" @selected($filters['store_id']==$store->id)>{{ $store->name }}</option>@endforeach</select></label>@elseif($isRetailScoped && $stores->count()>1)<label>{{ $ar?'المتجر الحالي':'Current store' }}<select name="store_id" onchange="this.form.submit()">@foreach($stores as $store)<option value="{{ $store->id }}" @selected($currentStoreId===$store->id)>{{ $store->name }}</option>@endforeach</select></label>@endif
<button class="btn foodex-filter-action">{{ $ar?'تصفية':'Filter' }}</button>
</form>
</section>

@if($manageableScopes!==[])
<div class="lookup-modal" data-lookup-modal data-auto-open="{{ old('_lookup_create')==='1'?'1':'0' }}" hidden>
    <div class="lookup-modal-backdrop" data-lookup-modal-close></div>
    <section class="lookup-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="lookup-create-title" tabindex="-1">
        <header class="lookup-modal-header">
            <div>
                <h2 id="lookup-create-title">{{ $createLabel }}</h2>
                <p>{{ $createDescription }}</p>
            </div>
            <button class="lookup-modal-close" type="button" aria-label="{{ $ar?'إغلاق':'Close' }}" data-lookup-modal-close>×</button>
        </header>
        <form method="post" enctype="multipart/form-data" action="{{ route('admin.lookups.store',$type) }}">
            @csrf
            <input type="hidden" name="_lookup_create" value="1">
            <div class="lookup-modal-body">
                <div class="form-grid">
                    @if($isSuperAdmin)
                    <label>{{ $ar?'النطاق':'Scope' }}<select name="scope" required>@foreach($manageableScopes as $scope)<option value="{{ $scope }}" @selected(old('scope')===$scope)>{{ $scopeLabels[$scope] }}</option>@endforeach</select></label>
                    @if($stores->isNotEmpty())<label>{{ $ar?'المتجر عند اختيار Retail':'Store for Retail scope' }}<select name="store_id"><option value="">—</option>@foreach($stores as $store)<option value="{{ $store->id }}" @selected((string)old('store_id')===(string)$store->id)>{{ $store->name }}</option>@endforeach</select></label>@endif
                    @elseif($isB2bAdmin)
                    <input type="hidden" name="scope" value="b2b">
                    @elseif($isRetailScoped)
                    <input type="hidden" name="scope" value="store"><input type="hidden" name="store_id" value="{{ $currentStoreId }}">
                    @endif
                    <label>{{ $ar?'الاسم بالعربية':'Arabic name' }}<input name="name_ar" value="{{ old('name_ar') }}" placeholder="{{ $type==='brands'?($ar?'مثال: كوكاكولا':'e.g. Coca-Cola'):($ar?'مثال: قطعة':'e.g. Piece') }}" required></label>
                    <label>{{ $ar?'الاسم بالإنجليزية':'English name' }}<input name="name_en" value="{{ old('name_en') }}" placeholder="{{ $type==='brands'?'e.g. Coca-Cola':'e.g. Piece' }}" required></label>
                    @if($type==='brands')
                    <label>{{ $ar?'المعرّف النصي':'Slug' }}<input name="slug" value="{{ old('slug') }}" placeholder="{{ $ar?'مثال: coca-cola':'e.g. coca-cola' }}"></label>
                    <label>{{ $ar?'صورة العلامة':'Brand image' }}<input type="file" name="brand_image" accept="image/jpeg,image/png,image/webp" required class="js-brand-image-preview"><span class="image-help">{{ $ar?'يفضل 512×512 بكسل. المسموح 256×256 إلى 2048×2048، JPG/PNG/WebP، حتى 2MB.':'Recommended 512×512 px. Allowed 256×256 to 2048×2048, JPG/PNG/WebP, max 2 MB.' }}</span></label>
                    @else
                    <label>{{ $ar?'الكود':'Code' }}<input name="code" value="{{ old('code') }}" placeholder="{{ $ar?'مثال: PCS':'e.g. PCS' }}" required></label>
                    <label>{{ $ar?'المنازل العشرية':'Decimal places' }}<input type="number" name="decimal_places" min="0" max="6" value="{{ old('decimal_places',0) }}" placeholder="0" required></label>
                    @endif
                    <label><span>{{ $ar?'الحالة':'Status' }}</span><span><input type="checkbox" name="is_active" value="1" @checked(old('is_active','1')==='1') style="min-width:auto"> {{ $ar?'نشط':'Active' }}</span></label>
                    @if($isSuperAdmin)<label class="support"><input type="checkbox" name="support_access" value="1" @checked(old('support_access'))> {{ $ar?'دخول دعم صريح عند إدارة نطاق متجر':'Explicit support access for store-scoped changes' }}</label>@endif
                </div>
            </div>
            <footer class="lookup-modal-actions">
                <button class="btn" type="button" data-lookup-modal-close>{{ $ar?'إلغاء':'Cancel' }}</button>
                <button class="btn primary" type="submit">＋ {{ $createLabel }}</button>
            </footer>
        </form>
    </section>
</div>
@endif

<section class="card table-wrap">
<table class="table">
<thead><tr>@if($type==='brands')<th>{{ $ar?'الصورة':'Image' }}</th>@endif<th>{{ $ar?'المفتاح':'Key' }}</th><th>{{ $ar?'العربية':'Arabic' }}</th><th>{{ $ar?'الإنجليزية':'English' }}</th><th>{{ $ar?'النطاق':'Scope' }}</th><th>{{ $ar?'المتجر':'Store' }}</th><th>{{ $ar?'الحالة':'Status' }}</th><th>{{ $ar?'الإجراءات':'Actions' }}</th></tr></thead>
<tbody>
@forelse($records as $record)
@php($recordDisplayName = app()->getLocale()==='ar' ? ($record->name_ar ?: $record->name_en) : ($record->name_en ?: $record->name_ar))
<tr class="lookup-record-row">
@if($type==='brands')<td class="lookup-mobile-full" data-label="{{ __('catalog_grid.image') }}"><div class="lookup-grid-image">@if($record->image_path)<img class="brand-thumb" src="{{ url('/'.ltrim($record->image_path,'/')) }}" alt="{{ $recordDisplayName }}">@else<span class="muted">—</span>@endif @if($record->can_manage)<form method="post" enctype="multipart/form-data" action="{{ route('admin.lookups.brands.image',['lookup'=>$record->id]) }}" class="lookup-grid-image-form" data-grid-image-form>@csrf @method('PATCH')@if($isSuperAdmin && $record->scope==='store')<label class="support"><input type="checkbox" name="support_access" value="1"> {{ __('catalog_grid.support_access') }}</label>@endif<label class="lookup-grid-image-trigger">{{ __('catalog_grid.change_image') }}<input class="lookup-grid-image-input" data-grid-image-input type="file" name="brand_image" accept="image/jpeg,image/png,image/webp" required></label></form>@endif</div></td>@endif
<td data-label="{{ __('catalog_grid.key') }}">{{ $type==='brands'?$record->slug:$record->code }}</td>
<td data-label="{{ __('catalog_grid.arabic') }}">{{ $record->name_ar }}</td><td data-label="{{ __('catalog_grid.english') }}">{{ $record->name_en }}</td> {{-- localization-gate: allow bilingual lookup management intentionally exposes both source-language fields --}}
<td data-label="{{ __('catalog_grid.scope') }}"><span class="badge">{{ $scopeLabels[$record->scope]??$record->scope }}</span></td>
<td data-label="{{ __('catalog_grid.store') }}">{{ $record->store_name?:'—' }}</td>
<td data-label="{{ __('catalog_grid.status') }}"><span class="badge {{ $record->is_active?'on':'off' }}">{{ $record->is_active ? __('catalog_grid.active') : __('catalog_grid.inactive') }}</span></td>
<td class="lookup-mobile-full" data-label="{{ __('catalog_grid.actions') }}">
@if($record->can_manage)
<form class="inline-form" method="post" enctype="multipart/form-data" action="{{ route('admin.lookups.update',['type'=>$type,'lookup'=>$record->id]) }}">@csrf @method('PATCH')
<label>{{ $ar?'العربية':'AR' }}<input name="name_ar" value="{{ $record->name_ar }}" required></label><label>{{ $ar?'الإنجليزية':'EN' }}<input name="name_en" value="{{ $record->name_en }}" required></label>
@if($type==='brands')<label>{{ $ar?'المعرّف النصي':'Slug' }}<input name="slug" value="{{ $record->slug }}" placeholder="{{ $ar?'مثال: coca-cola':'e.g. coca-cola' }}" placeholder="{{ $ar?'مثال: coca-cola':'e.g. coca-cola' }}" required></label><label>{{ $ar?'استبدال الصورة':'Replace image' }}<input type="file" name="brand_image" accept="image/jpeg,image/png,image/webp" @required(!$record->image_path) class="js-brand-image-preview"><span class="image-help">{{ $ar?'512×512 مفضل؛ 256–2048 بكسل، حتى 2MB.':'512×512 recommended; 256–2048 px, max 2 MB.' }}</span></label>@else<label>{{ $ar?'الكود':'Code' }}<input name="code" value="{{ $record->code }}" placeholder="{{ $ar?'مثال: PCS':'e.g. PCS' }}" placeholder="{{ $ar?'مثال: PCS':'e.g. PCS' }}" required></label><label>{{ $ar?'الدقة':'Precision' }}<input type="number" min="0" max="6" name="decimal_places" value="{{ $record->decimal_places }}" placeholder="0" placeholder="0" required></label>@endif
@if($isSuperAdmin)
<label>{{ $ar?'النطاق':'Scope' }}<select name="scope">@foreach($manageableScopes as $scope)<option value="{{ $scope }}" @selected($record->scope===$scope)>{{ $scopeLabels[$scope] }}</option>@endforeach</select></label>
@if($stores->isNotEmpty())<label>{{ $ar?'المتجر':'Store' }}<select name="store_id"><option value="">—</option>@foreach($stores as $store)<option value="{{ $store->id }}" @selected($record->store_id==$store->id)>{{ $store->name }}</option>@endforeach</select></label>@endif
@elseif($record->scope==='b2b')
<input type="hidden" name="scope" value="b2b">
@elseif($record->scope==='store')
<input type="hidden" name="scope" value="store"><input type="hidden" name="store_id" value="{{ $record->store_id }}">
@endif
<input type="hidden" name="is_active" value="{{ $record->is_active?1:0 }}">
@if($isSuperAdmin)<label class="support"><input type="checkbox" name="support_access" value="1"> {{ $ar?'دعم صريح عند النقل/الإدارة بنطاق متجر':'Explicit support access for store scope' }}</label>@endif
<button class="btn">{{ $ar?'حفظ':'Save' }}</button>
</form>
<div class="actions" style="margin-top:8px">
<form method="post" action="{{ route('admin.lookups.toggle',['type'=>$type,'lookup'=>$record->id]) }}">@csrf @method('PATCH') @if($isSuperAdmin && $record->scope==='store')<label class="support"><input type="checkbox" name="support_access" value="1"> {{ $ar?'دعم صريح':'Support access' }}</label>@endif<button class="btn">{{ $record->is_active?($ar?'تعطيل':'Deactivate'):($ar?'تفعيل':'Activate') }}</button></form>
<form method="post" action="{{ route('admin.lookups.destroy',['type'=>$type,'lookup'=>$record->id]) }}" onsubmit="return confirm('{{ $ar?'تأكيد الحذف الآمن؟':'Confirm safe delete?' }}')">@csrf @method('DELETE') @if($isSuperAdmin && $record->scope==='store')<label class="support"><input type="checkbox" name="support_access" value="1"> {{ $ar?'دعم صريح':'Support access' }}</label>@endif<button class="btn danger">{{ $ar?'حذف':'Delete' }}</button></form>
</div>
@else
<span class="muted">{{ $ar?'للقراءة فقط في هذا النطاق':'Read-only in this scope' }}</span>
@endif
</td>
</tr>
@empty<tr><td colspan="{{ $type==='brands'?8:7 }}">{{ $ar?'لا توجد قيم مطابقة.':'No matching lookup values.' }}</td></tr>@endforelse
</tbody></table>
<div>{{ $records->links() }}</div>
</section>
</main></div>
<script>
(() => {
    document.querySelectorAll('[data-grid-image-input]').forEach((input) => {
        input.addEventListener('change', () => {
            const form = input.closest('[data-grid-image-form]');
            if (!form || !input.files || input.files.length === 0) return;
            form.classList.add('is-uploading');
            if (typeof form.requestSubmit === 'function') form.requestSubmit();
            else form.submit();
        });
    });

    document.querySelectorAll('.js-brand-image-preview').forEach((input) => {
        const preview = document.createElement('div');
        preview.className = 'brand-upload-preview';
        input.insertAdjacentElement('afterend', preview);
        input.addEventListener('change', () => {
            preview.replaceChildren();
            const file = input.files && input.files[0];
            if (!file || !file.type.startsWith('image/')) return;
            const image = document.createElement('img');
            image.alt = file.name;
            image.src = URL.createObjectURL(file);
            image.addEventListener('load', () => URL.revokeObjectURL(image.src), {once:true});
            preview.appendChild(image);
        });
    });

    const modal = document.querySelector('[data-lookup-modal]');
    const opener = document.querySelector('[data-lookup-modal-open]');
    if (!modal || !opener) return;

    const dialog = modal.querySelector('.lookup-modal-dialog');
    let previousFocus = null;

    const openModal = () => {
        previousFocus = document.activeElement;
        modal.hidden = false;
        document.documentElement.classList.add('lookup-modal-open');
        requestAnimationFrame(() => dialog?.focus());
    };

    const closeModal = () => {
        modal.hidden = true;
        document.documentElement.classList.remove('lookup-modal-open');
        if (previousFocus instanceof HTMLElement) previousFocus.focus();
    };

    opener.addEventListener('click', openModal);
    modal.querySelectorAll('[data-lookup-modal-close]').forEach((control) => control.addEventListener('click', closeModal));
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !modal.hidden) closeModal();
    });

    if (modal.dataset.autoOpen === '1') openModal();
})();
</script>
</body></html>
