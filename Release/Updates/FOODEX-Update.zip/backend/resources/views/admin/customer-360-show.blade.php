<!doctype html>
<html lang="{{ str_replace('_','-',app()->getLocale()) }}" dir="{{ app()->getLocale()==='ar'?'rtl':'ltr' }}">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ $customer->name }} · {{ app()->getLocale()==='ar'?'العميل 360':'Customer 360' }} · FOODEX</title>
@include('admin._brand-components')
<style>
.c360-shell{display:grid;gap:var(--foodex-space-5)}.c360-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.c360-card{padding:var(--foodex-space-5)}
.c360-card h2,.c360-card h3{margin:0}.c360-card p{color:var(--foodex-muted)}.c360-stat{display:grid;gap:4px}.c360-stat strong{font-size:24px}.c360-stat small{color:var(--foodex-muted)}
.c360-badge{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--foodex-border);border-radius:999px;padding:5px 9px;font-size:12px;font-weight:800;background:#fff}.c360-badge.active{background:var(--foodex-green-soft);color:var(--foodex-green-dark);border-color:transparent}.c360-badge.b2b{background:#fff7ed;color:#9a3412}.c360-badge.b2c{background:#eefbf4;color:#166534}
.c360-info{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}.c360-info>div{padding:14px;border:1px solid var(--foodex-border);border-radius:var(--foodex-radius-control);background:#fbfcfd}.c360-info small{display:block;color:var(--foodex-muted);margin-bottom:4px}.c360-info strong{word-break:break-word}
.c360-table{width:100%;border-collapse:collapse}.c360-table th,.c360-table td{padding:12px;border-bottom:1px solid var(--foodex-border);text-align:start;vertical-align:top}.c360-table th{font-size:12px;color:var(--foodex-muted);background:#f8fafc}.c360-table tr:hover td{background:#fbfefc}
.c360-list{display:flex;gap:8px;flex-wrap:wrap}.c360-store{padding:9px 12px;border:1px solid var(--foodex-border);border-radius:999px;background:#fff;font-weight:800}.c360-actions{display:flex;gap:8px;flex-wrap:wrap}
@media(max-width:1050px){.c360-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:720px){.c360-grid{grid-template-columns:1fr}.c360-table thead{display:none}.c360-table,.c360-table tbody,.c360-table tr,.c360-table td{display:block;width:100%}.c360-table tr{padding:10px 0;border-bottom:1px solid var(--foodex-border)}.c360-table td{border:0;padding:7px 0}.c360-table td:before{content:attr(data-label);display:block;font-size:11px;font-weight:800;color:var(--foodex-muted);margin-bottom:2px}}
</style>
</head>
<body>
@php($ar=app()->getLocale()==='ar')
<div class="foodex-admin-layout">
    <aside class="sidebar">@include('admin._sidebar')</aside>
    <main class="foodex-admin-main foodex-admin-page">
        <header class="foodex-page-header">
            <div>
                <span class="foodex-subtitle">FOODEX · CUSTOMER 360 · #{{ $customer->id }}</span>
                <h1>{{ $customer->name }}</h1>
                <p>{{ $ar?'عرض موحد للهوية والتعاملات داخل النطاق المصرح لك فقط.':'Unified identity and commerce view restricted to your authorized scope.' }}</p>
            </div>
            <div class="c360-actions">
                <a class="foodex-action-secondary button secondary" href="{{ route('admin.customer-360.index') }}">← {{ $ar?'العودة للعملاء':'Back to customers' }}</a>
                @include('admin._live-notifications',['user'=>auth()->user()])
            </div>
        </header>

        <div class="c360-shell">
            <section class="c360-grid">
                <article class="foodex-card c360-card c360-stat">
                    <small>{{ $ar?'الحالة':'Status' }}</small>
                    <strong>{{ $summary['active']?($ar?'نشط':'Active'):($ar?'غير نشط':'Inactive') }}</strong>
                    <span class="c360-badge {{ $summary['active']?'active':'' }}">{{ $summary['registration_source'] }}</span>
                </article>
                <article class="foodex-card c360-card c360-stat">
                    <small>{{ $ar?'الطلبات':'Orders' }}</small>
                    <strong>{{ number_format($summary['orders_count']) }}</strong>
                    <span>{{ number_format($summary['orders_total'],3) }} EGP</span>
                </article>
                <article class="foodex-card c360-card c360-stat">
                    <small>{{ $ar?'الفواتير':'Invoices' }}</small>
                    <strong>{{ number_format($summary['invoices_count']) }}</strong>
                    <span>{{ number_format($summary['invoices_total'],3) }} EGP</span>
                </article>
                <article class="foodex-card c360-card c360-stat">
                    <small>{{ $ar?'مصدر التسجيل':'Registration origin' }}</small>
                    <strong style="font-size:16px">{{ $summary['origin']['label'] }}</strong>
                    <span class="c360-badge {{ $summary['origin']['channel'] }}">{{ strtoupper($summary['origin']['channel']) }}</span>
                </article>
            </section>

            <section class="foodex-card c360-card">
                <h2>{{ $ar?'هوية العميل':'Customer identity' }}</h2>
                <div class="c360-info" style="margin-top:16px">
                    <div><small>{{ $ar?'الاسم':'Name' }}</small><strong>{{ $customer->name }}</strong></div>
                    <div><small>{{ $ar?'البريد الإلكتروني':'Email' }}</small><strong>{{ $customer->email }}</strong></div>
                    <div><small>{{ $ar?'الهاتف':'Phone' }}</small><strong>{{ $customer->phone ?: '-' }}</strong></div>
                    <div><small>{{ $ar?'تاريخ التسجيل':'Registered at' }}</small><strong>{{ optional($customer->registered_at)->format('Y-m-d H:i') ?: '-' }}</strong></div>
                    <div><small>{{ $ar?'قناة التسجيل الأصلية':'Immutable origin channel' }}</small><strong>{{ strtoupper($customer->origin_channel ?: 'unknown') }}</strong></div>
                    <div><small>{{ $ar?'مصدر التسجيل':'Registration source' }}</small><strong>{{ $customer->registration_source }}</strong></div>
                </div>
            </section>

            @if($wholesale)
            <section class="foodex-card c360-card">
                <h2>{{ $ar?'حساب الجملة':'Wholesale account' }}</h2>
                <div class="c360-info" style="margin-top:16px">
                    <div><small>{{ $ar?'الشركة':'Company' }}</small><strong>{{ $wholesale['company_name'] ?: $customer->name }}</strong></div>
                    <div><small>{{ $ar?'الحالة':'Status' }}</small><strong>{{ $wholesale['status'] ?: '-' }}</strong></div>
                    <div><small>{{ $ar?'شريحة السعر':'Price tier' }}</small><strong>{{ $wholesale['tier_name'] ?: '-' }} @if($wholesale['tier_code'])· {{ $wholesale['tier_code'] }}@endif</strong></div>
                    <div><small>{{ $ar?'حد الائتمان':'Credit limit' }}</small><strong>{{ $wholesale['credit_limit']===null?'-':number_format($wholesale['credit_limit'],3).' EGP' }}</strong></div>
                </div>
            </section>
            @endif

            @if($access['mode']!=='b2b')
            <section class="foodex-card c360-card">
                <h2>{{ $ar?'متاجر التجزئة المرتبطة':'Materialized Retail stores' }}</h2>
                <p>{{ $ar?'تظهر فقط المتاجر التي يحق لك رؤيتها.':'Only Retail stores inside your authorization scope are shown.' }}</p>
                <div class="c360-list">
                    @forelse($retailStores as $store)
                        <span class="c360-store">{{ $store['name'] }} · {{ $store['code'] }}</span>
                    @empty
                        <span class="c360-store">{{ $ar?'لا توجد متاجر ضمن النطاق الحالي':'No Retail stores in the current scope' }}</span>
                    @endforelse
                </div>
            </section>
            @endif

            <section class="foodex-card c360-card">
                <h2>{{ $ar?'أحدث الطلبات':'Recent orders' }}</h2>
                <p>{{ $ar?'كل رابط يفتح مساحة الإدارة الخاصة بنفس القناة والمتجر.':'Each link opens the matching authorized channel/store workspace.' }}</p>
                @if(empty($orders))
                    <div class="foodex-empty-state">{{ $ar?'لا توجد طلبات داخل النطاق الحالي.':'No orders in the current scope.' }}</div>
                @else
                <div style="overflow:auto;margin-top:12px">
                    <table class="c360-table">
                        <thead><tr><th>{{ $ar?'الطلب':'Order' }}</th><th>{{ $ar?'المتجر':'Store' }}</th><th>{{ $ar?'القناة':'Channel' }}</th><th>{{ $ar?'الحالة':'Status' }}</th><th>{{ $ar?'الإجمالي':'Total' }}</th><th>{{ $ar?'التاريخ':'Date' }}</th><th></th></tr></thead>
                        <tbody>
                        @foreach($orders as $order)
                            <tr id="order-{{ $order['id'] }}">
                                <td data-label="{{ $ar?'الطلب':'Order' }}"><strong>{{ $order['number'] }}</strong></td>
                                <td data-label="{{ $ar?'المتجر':'Store' }}">{{ $order['store'] }}</td>
                                <td data-label="{{ $ar?'القناة':'Channel' }}"><span class="c360-badge {{ $order['channel'] }}">{{ strtoupper($order['channel']) }}</span></td>
                                <td data-label="{{ $ar?'الحالة':'Status' }}">{{ $order['status'] }}</td>
                                <td data-label="{{ $ar?'الإجمالي':'Total' }}">{{ number_format($order['total'],3) }} {{ $order['currency'] }}</td>
                                <td data-label="{{ $ar?'التاريخ':'Date' }}">{{ $order['created_at'] }}</td>
                                <td><a class="foodex-action-secondary button secondary" href="{{ $order['url'] }}">{{ $ar?'إدارة الطلب':'Manage order' }}</a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                @endif
            </section>

            <section class="foodex-card c360-card">
                <h2>{{ $ar?'الفواتير':'Invoices' }}</h2>
                <p>{{ $ar?'الفواتير هنا تستخدم نفس صلاحيات Finance وعزل المتاجر المطبق في النظام.':'Invoice links use the existing Finance authorization and store isolation.' }}</p>
                @if(empty($invoices))
                    <div class="foodex-empty-state">{{ $ar?'لا توجد فواتير داخل النطاق الحالي.':'No invoices in the current scope.' }}</div>
                @else
                <div style="overflow:auto;margin-top:12px">
                    <table class="c360-table">
                        <thead><tr><th>{{ $ar?'الفاتورة':'Invoice' }}</th><th>{{ $ar?'المتجر':'Store' }}</th><th>{{ $ar?'القناة':'Channel' }}</th><th>{{ $ar?'الحالة':'Status' }}</th><th>{{ $ar?'الإجمالي':'Total' }}</th><th>{{ $ar?'الإصدار':'Issued' }}</th><th></th></tr></thead>
                        <tbody>
                        @foreach($invoices as $invoice)
                            <tr>
                                <td data-label="{{ $ar?'الفاتورة':'Invoice' }}"><strong>{{ $invoice['number'] }}</strong></td>
                                <td data-label="{{ $ar?'المتجر':'Store' }}">{{ $invoice['store'] }}</td>
                                <td data-label="{{ $ar?'القناة':'Channel' }}"><span class="c360-badge {{ $invoice['channel'] }}">{{ strtoupper($invoice['channel']) }}</span></td>
                                <td data-label="{{ $ar?'الحالة':'Status' }}">{{ $invoice['status'] }}</td>
                                <td data-label="{{ $ar?'الإجمالي':'Total' }}">{{ number_format($invoice['total'],3) }} {{ $invoice['currency'] }}</td>
                                <td data-label="{{ $ar?'الإصدار':'Issued' }}">{{ $invoice['issued_at'] ?: '-' }}</td>
                                <td class="c360-actions"><a class="foodex-action-secondary button secondary" href="{{ $invoice['url'] }}">{{ $ar?'التفاصيل':'Details' }}</a><a class="foodex-action-primary" href="{{ $invoice['pdf_url'] }}">PDF</a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                @endif
            </section>
        </div>
    </main>
</div>
</body></html>
