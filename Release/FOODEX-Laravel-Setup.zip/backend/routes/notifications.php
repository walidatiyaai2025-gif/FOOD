<?php

use App\Http\Controllers\Admin\NotificationController as AdminNotificationController;
use App\Http\Controllers\Admin\PromotionalNotificationCampaignController;
use App\Http\Controllers\Api\V1\NotificationController as ApiNotificationController;
use Illuminate\Support\Facades\Route;

Route::middleware(['web', 'management.dashboard'])
    ->prefix('admin/notifications')
    ->name('admin.notifications.')
    ->group(function (): void {
        Route::get('/', [AdminNotificationController::class, 'index'])->name('index');
        Route::get('/live', [AdminNotificationController::class, 'live'])->name('live');
        Route::post('/read-all', [AdminNotificationController::class, 'markAllRead'])->name('read-all');
        Route::post('/{notification}/read', [AdminNotificationController::class, 'markRead'])->name('read');
        Route::post('/', [AdminNotificationController::class, 'store'])->name('store');
        Route::patch('/{notification}', [AdminNotificationController::class, 'update'])->name('update');
        Route::post('/{notification}/publish', [AdminNotificationController::class, 'publish'])->name('publish');
        Route::delete('/{notification}', [AdminNotificationController::class, 'destroy'])->name('destroy');
    });

Route::middleware(['web', 'management.dashboard'])
    ->prefix('admin/notification-campaigns')
    ->name('admin.notification-campaigns.')
    ->group(function (): void {
        Route::get('/', [PromotionalNotificationCampaignController::class, 'index'])->name('index');
        Route::post('/', [PromotionalNotificationCampaignController::class, 'store'])->name('store');
        Route::patch('/{campaign}', [PromotionalNotificationCampaignController::class, 'update'])->name('update');
        Route::post('/{campaign}/state', [PromotionalNotificationCampaignController::class, 'state'])->name('state');
        Route::post('/{campaign}/send-now', [PromotionalNotificationCampaignController::class, 'sendNow'])->name('send-now');
    });

Route::middleware(['api', 'auth:sanctum', 'active.user'])
    ->prefix('api/v1/notifications')
    ->name('api.notifications.')
    ->group(function (): void {
        Route::get('/', [ApiNotificationController::class, 'index'])->name('index');
        Route::get('/{notification}', [ApiNotificationController::class, 'show'])->name('show');
        Route::post('/{notification}/read', [ApiNotificationController::class, 'markRead'])->name('read');
    });
